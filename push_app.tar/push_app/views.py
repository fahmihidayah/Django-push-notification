from django.views.generic import DetailView, ListView, UpdateView, CreateView
from .models import PushApplication
from .forms import PushApplicationForm


class PushApplicationListView(ListView):
    model = PushApplication


class PushApplicationCreateView(CreateView):
    model = PushApplication
    form_class = PushApplicationForm


class PushApplicationDetailView(DetailView):
    model = PushApplication


class PushApplicationUpdateView(UpdateView):
    model = PushApplication
    form_class = PushApplicationForm

