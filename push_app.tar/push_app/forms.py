from django import forms
from .models import PushApplication


class PushApplicationForm(forms.ModelForm):
    class Meta:
        model = PushApplication
        fields = ['name', 'description', 'api_key', 'user']


